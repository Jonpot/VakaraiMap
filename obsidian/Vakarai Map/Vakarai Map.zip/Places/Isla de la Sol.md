---
icon: place
---
# Isla de la Sol
One of the many Coastal Teleport Tower Towns built by [[The Netherese Empire]].
