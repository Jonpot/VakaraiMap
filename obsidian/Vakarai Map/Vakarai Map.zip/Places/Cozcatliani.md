---
icon: place
---
# Cozcatliani, Amber Outpost
This is a small outpost in the [[Sea of Amber]] where the people of [[Allenore]] could keep an eye on [[Metzalnoc]], who has been causing some problems recently. However, the mission of the party will be to see what has happened. The people of Cozcatliani have not been heard from, not even a “Seastrider,” or someone who travels between Cozcat and [[Allenore]], has been seen recently. 
