---
icon: place
---
# Pueblo de la Playa
One of the many Coastal Teleport Tower Towns built by [[The Netherese Empire]].
