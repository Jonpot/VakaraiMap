---
icon: place
---
# Cartef Caled
An abandoned [[The Otmen|Otmanx]] town in the [[Promethean Forest]] that used to be a site where Otmen could gather the necessary ingredients to make a Vilatti.