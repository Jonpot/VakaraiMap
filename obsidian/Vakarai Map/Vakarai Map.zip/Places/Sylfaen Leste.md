---
icon: place
---
# Sylfaen Leste
An abandoned [[Otmanx]] town in the [[Eastern Vakarai Jungle]] that used to be a site where Otmen first encountered the Liameni.
