---
icon: place
---
# Gillhome
A giant mystical lake in the middle of the jungle, underwater in [[Lago Palatano]]. Unfortunately, the people that dwell within are the Gillhominids, who are a politically complicated amphibious people. Who knows what secrets lie within the city? The lake is also full of all kinds of wondrous creatures, and lots of sharks, which the Gillhominids can command.