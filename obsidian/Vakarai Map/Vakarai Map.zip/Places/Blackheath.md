---
icon: place
---
# Blackheath
The remains of a fortified outpost atop a series of connected peaks in the center of the Frost Emerald Mountain Range. 