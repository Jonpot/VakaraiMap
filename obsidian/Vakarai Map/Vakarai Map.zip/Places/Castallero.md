---
icon: place
---
# Castallero
A coastal town on the eastern peninsula of [[Vakarai]]. Near the mouth of the Palatano River.

Goverened by the Imperial Adjunct, [[Tulus Olympicus]] and the Guild's high trade prince, [[Luis Miguel Saldana]]. 
