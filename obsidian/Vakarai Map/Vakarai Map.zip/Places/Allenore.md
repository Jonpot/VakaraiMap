---
icon: place
---
# Allenore
A beautiful city in the [[Palatano River Valley]]. In this setting, [[The Liameni]] resemble elves of sorts, and their architecture is similarly elegant and stunning. The city is full of colorful orchids. The leader of the people is [[Queen Mairuna|Mairuna, Queen of Orchids]]. There is also a high council of the religious group, known as the [[The Council of Pontiffs|High Pontiffs]]. Districts in the city are arranged via elevation. The population is not very large compared to, say, [[The Netherese Empire|the empire]]–but the people are much more long-lived and powerful than the average citizen of [[The Netherese Empire|the empire]].

Referred to by [[The Netherese Empire|the Empire]] as La Vista del Flores.