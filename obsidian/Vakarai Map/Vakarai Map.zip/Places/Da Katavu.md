---
icon: place
---
# Da Katavu
A collosal, slumbering beast in the center of the continent, Da Katavu is the only reliable way to physically transport one's self into [[Da Sonhe]].