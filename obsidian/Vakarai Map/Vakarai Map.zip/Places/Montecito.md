---
icon: place
---
# Montecito
One of the many Coastal Teleport Tower Towns built by [[The Netherese Empire]].
