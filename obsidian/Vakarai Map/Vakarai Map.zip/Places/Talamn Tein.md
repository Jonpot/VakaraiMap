---
icon: place
---
# Talamn Tein
An abandoned Otmanx town in the [[Crimson Graveyard]] that used to be a site where [[Otmen]] would send [[the Watchers]] into [[Ashenmist]] to perform transmutation experiments.