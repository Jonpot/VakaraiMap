---
icon: biome
---
# Shell of Koj

*Unvisited by the party!*