---
icon: biome
---
# Allenore Steppes
A gentle valley with grass, light deciduous forest (oaks, etc), and plenty of wildflowers. Allenore is in the seat of this valley, surrounded by waterfalls of the Rio Palatano.

***Locations of Note***:
- [[Allenore]]

***Climate Conditions:***
-   **Temperature:** Mild, 60s.
-   **Precipitation:** Seasonal.
-   **Humidity:** Not too bad.
-   **Wind/Storms:** Mild conditions.

> [!ERROR]- **Additional Environmental Conditions**
> - Anyone with a pollen allergy is going to have a tough time during the spring, but otherwise, a very hospitable region. No wonder the Liameni chose to set up here.
