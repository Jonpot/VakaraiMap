---
icon: biome
---
# Frost Emerald Mountains

*Unvisited by the party!*