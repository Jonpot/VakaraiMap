---
icon: biome
---
# Jewel Crown Forest

*Unvisited by the party!*
